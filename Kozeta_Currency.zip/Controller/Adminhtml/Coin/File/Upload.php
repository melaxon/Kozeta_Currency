<?php
/**
 * @author Kozeta Team
 * @copyright Copyright (c) 2019 Kozeta (https://www.kozeta.lt)
 * @package Kozeta_Curency
 */

namespace Kozeta\Currency\Controller\Adminhtml\Coin\File;

use Kozeta\Currency\Controller\Adminhtml\Coin\Upload as GenericUpload;

class Upload extends GenericUpload
{

}
