/**
 * For older versions of Magento2
 */
var config = {
    map: {
        '*': {
            'Magento_Catalog/js/price-utils' : 'Kozeta_Currency/js/price-utils'
        }
    }
};